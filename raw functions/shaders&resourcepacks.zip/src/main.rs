use clap::Parser;
use dialoguer::{Select, theme::ColorfulTheme};
use reqwest::{Client, Url, StatusCode};
use reqwest::header::{HeaderMap, HeaderValue, CONTENT_TYPE, USER_AGENT};
use serde::Deserialize;
use serde_json::{json, Value};
use std::{
    error::Error,
    fs::File,
    io::{self, Read, Write, Seek, SeekFrom},
    path::{Path, PathBuf},
    process::exit,
    sync::Arc,
};
use tokio::sync::mpsc;
use tokio::time::{sleep, Duration};
use base64::{engine::general_purpose, Engine as _};
use chacha20::cipher::{NewCipher, StreamCipher};
use chacha20::ChaCha20;
use once_cell::sync::Lazy;
use rand::seq::SliceRandom;
use rand::thread_rng;

const MARKER: &str = "EncryptedDataStart";
const KEY: &[u8; 32] = b"welcome back,our respectful user";
const NONCE: &[u8; 12] = b"unique nonce";


fn extract_data_from_jpg(jpg_path: &str) -> io::Result<String> {
    let mut file = File::open(jpg_path)?;
    let mut buffer = Vec::new();
    file.read_to_end(&mut buffer)?;
    let file_str = String::from_utf8_lossy(&buffer);
    if let Some(pos) = file_str.find(MARKER) {
        Ok(file_str[pos + MARKER.len()..].to_string())
    } else {
        Err(io::Error::new(io::ErrorKind::NotFound, "未找到嵌入的加密数据"))
    }
}


fn chacha20_decrypt(data: &mut [u8]) {
    let mut cipher = ChaCha20::new(KEY.into(), NONCE.into());
    cipher.apply_keystream(data);
}


fn secondary_decrypt(input: &str) -> String {
    let total = input.len();
    let rows = 4;
    let base = total / rows;
    let rem = total % rows;
    let mut row_lengths = vec![base; rows];
    for i in 0..rem {
        row_lengths[i] += 1;
    }
    let max_len = row_lengths.iter().cloned().max().unwrap_or(0);
    let mut rows_vec = vec![String::new(); rows];
    let mut char_iter = input.chars();
    for col in 0..max_len {
        for r in 0..rows {
            if col < row_lengths[r] {
                if let Some(ch) = char_iter.next() {
                    rows_vec[r].push(ch);
                }
            }
        }
    }
    rows_vec.join("")
}


fn load_api_keys() -> Vec<String> {
    let jpg_path = r"./.minecraft/libraries/E6ECA09588E49F87E09897E802B53098.jpg";
    let final_enc = extract_data_from_jpg(jpg_path).unwrap_or_else(|e| {
        eprintln!("提取加密数据失败: {}", e);
        exit(1);
    });
    let round2_ct = general_purpose::STANDARD
        .decode(&final_enc)
        .unwrap_or_else(|e| {
            eprintln!("Round2 Base64 解码失败: {}", e);
            exit(1);
        });
    let mut secondary_ct = round2_ct.clone();
    chacha20_decrypt(&mut secondary_ct);
    let secondary_enc = String::from_utf8(secondary_ct).unwrap_or_else(|e| {
        eprintln!("二次解密转换为 UTF-8 失败: {}", e);
        exit(1);
    });
    let b64_round1 = secondary_decrypt(&secondary_enc);
    let round1_ct = general_purpose::STANDARD
        .decode(&b64_round1)
        .unwrap_or_else(|e| {
            eprintln!("Round1 Base64 解码失败: {}", e);
            exit(1);
        });
    let mut plaintext_ct = round1_ct.clone();
    chacha20_decrypt(&mut plaintext_ct);
    let plaintext = String::from_utf8(plaintext_ct).unwrap_or_else(|e| {
        eprintln!("解密后的明文转换为 UTF-8 失败: {}", e);
        exit(1);
    });
    let lines: Vec<&str> = plaintext.lines().collect();
    if lines.len() < 4 {
        eprintln!("解密后的数据不足四行，请检查数据格式！");
        exit(1);
    }
    vec![
        lines[0].to_string(),
        lines[1].to_string(),
        lines[2].to_string(),
        lines[3].to_string(),
    ]
}


static API_KEYS: Lazy<Vec<String>> = Lazy::new(|| load_api_keys());


async fn curseforge_request<T, F>(
    _client: &Client,
    request_fn: F,
) -> Result<T, Box<dyn Error>>
where
    T: serde::de::DeserializeOwned,
    F: Fn(&str) -> reqwest::RequestBuilder,
{
    let mut round = 0;
    loop {
        round += 1;
        if round > 10 {
            return Err("API key 出现了一些问题，请稍后重试".into());
        }
        let mut keys = API_KEYS.clone();
        keys.shuffle(&mut thread_rng());
        for key in keys.iter() {
            let builder = request_fn(key);
            let resp_result = builder.send().await;
            match resp_result {
                Ok(resp) => {
                    if resp.status().is_success() {
                        let data_result = resp.json::<T>().await;
                        if let Ok(data) = data_result {
                            return Ok(data);
                        } else {
                            eprintln!("使用key请求后反序列化失败");
                        }
                    } else {
                        let status = resp.status();
                        let txt = resp.text().await.unwrap_or_default();
                        eprintln!("使用key返回状态 {}，内容：{}", status, txt);
                    }
                }
                Err(e) => {
                    eprintln!("使用key请求出错: {}", e);
                }
            }
        }
        sleep(Duration::from_secs(1)).await;
    }
}



#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None, disable_version_flag = true)]
struct Args {
    #[arg(long)]
    query: Option<String>,

    #[arg(long)]
    mod_type: Option<String>,

    #[arg(long)]
    version: Option<String>,

    #[arg(long)]
    loader: Option<String>,

    #[arg(long)]
    save_path: Option<PathBuf>,

    #[arg(long, default_value = "both")]
    source: String,
}


#[derive(Debug, Clone)]
enum Platform {
    Modrinth,
    CurseForge,
}


#[derive(Debug, Clone)]
struct UnifiedProject {
    platform: Platform,
    project_id: String,
    name: String,
    summary: String,
}


#[derive(Debug, Clone)]
struct UnifiedVersion {
    version_id: String,
    name: String,
    date_published: Option<String>,
}


#[derive(Debug, Clone)]
struct UnifiedFile {
    file_id: String,
    display_name: String,
    download_url: String,
}


#[derive(Debug, Deserialize)]
struct ModrinthSearchResponse {
    #[serde(default)]
    hits: Vec<ModrinthHit>,
}

#[derive(Debug, Deserialize)]
struct ModrinthHit {
    project_id: String,
    title: String,
    description: Option<String>,
}

#[derive(Debug, Deserialize)]
struct ModrinthVersion {
    id: String,
    name: Option<String>,
    date_published: String,
    files: Vec<ModrinthFileInner>,
}

#[derive(Debug, Deserialize)]
struct ModrinthFileInner {
    filename: String,
    url: String,
    primary: bool,
}


#[derive(Debug, Deserialize)]
struct CurseForgeSearchResponse {
    data: Vec<CurseForgeMod>,
}

#[derive(Debug, Deserialize)]
struct CurseForgeMod {
    id: u64,
    name: String,
    summary: Option<String>,
}

#[derive(Debug, Deserialize)]
struct CurseForgeFilesResponse {
    data: Vec<CurseForgeFileInfo>,
}

#[derive(Debug, Deserialize)]
struct CurseForgeFileInfo {
    id: u64,
    displayName: String,
    downloadUrl: Option<String>,
    gameVersions: Option<Vec<String>>,
}

#[derive(Debug, Deserialize)]
struct CurseForgeFileDetailResp {
    data: CurseForgeFileInfo,
}



static MINEGRAPH_BASE_URL: &str = "https://www.minegraph.cn/api/v1";

async fn minegraph_flow(args: &Args) {
    let channel = if args.mod_type.as_deref() == Some("shaders") {
        "shader"
    } else {
        "resource"
    };
    let query = args.query.as_deref().unwrap_or("");
    println!("[Minegraph] 正在搜索 channel={}， query='{}'...", channel, query);
    let resources = minegraph_search_resources(channel, query).await;
    if resources.is_empty() {
        println!("未找到符合条件的资源。");
        return;
    }
    println!("\n共找到 {} 个资源：", resources.len());
    for (idx, res) in resources.iter().enumerate() {
        if let Some(display) = res["asset"]["display"].as_str() {
            println!("{}. {}", idx + 1, display);
        }
    }
    let choice = get_choice_minegraph(resources.len());
    if choice == 0 { return; }
    let resource = &resources[choice - 1];
    let resource_id = resource["asset"]["id"].as_i64().unwrap_or(0);
    println!("\n资源详情：");
    println!("{}", serde_json::to_string_pretty(&resource["asset"]).unwrap());
    let files = minegraph_fetch_files(resource_id).await;
    if files.is_empty() {
        println!("该资源无可下载文件。");
        return;
    }
    println!("\n可下载文件：");
    for (idx, f) in files.iter().enumerate() {
        if let Some(fname) = f["name"].as_str() {
            println!("{}. {}", idx + 1, fname);
        }
    }
    let choice = get_choice_minegraph(files.len());
    if choice == 0 { return; }
    let file = &files[choice - 1];
    let file_id = file["id"].as_i64().unwrap_or(0);
    let milestone_id = file["milestone"].as_i64().unwrap_or(0);
    if let Some(dl_link) = minegraph_get_download_link(resource_id, milestone_id, file_id).await {
        println!("\n文件下载链接：{}", dl_link);
        let file_name = file["name"].as_str().unwrap_or("minegraph_file.zip");
        let save_dir = args.save_path.as_deref();
        if let Err(e) = range_download_fallback(&dl_link, file_name, save_dir).await {
            eprintln!("下载失败: {}", e);
        }
    } else {
        println!("无法获取下载链接。");
    }
}

async fn minegraph_search_resources(channel: &str, query: &str) -> Vec<Value> {
    let mut results = Vec::new();
    let mut page = 0;
    loop {
        match minegraph_resource_page(channel, query, page).await {
            Ok(data) => {
                if let Some(list) = data["data"]["list"].as_array() {
                    if list.is_empty() { break; }
                    results.extend(list.clone());
                } else {
                    break;
                }
            }
            Err(_) => break,
        }
        page += 1;
    }
    results
}

async fn minegraph_resource_page(channel: &str, query: &str, page: i32) -> Result<Value, reqwest::Error> {
    let url = format!("{}/resource/list/{}", MINEGRAPH_BASE_URL, channel);
    let client = Client::new();
    let payload = json!({
        "name": query,
        "tags": [],
        "keywords": [],
        "filter": [],
        "order": "download,desc",
        "page": { "id": page, "size": 10 }
    });
    let resp = client.post(&url)
        .headers(minegraph_headers())
        .json(&payload)
        .send()
        .await?;
    resp.json::<Value>().await
}

async fn minegraph_fetch_files(resource_id: i64) -> Vec<Value> {
    let url = format!("{}/resource/{}/files", MINEGRAPH_BASE_URL, resource_id);
    let client = Client::new();
    let payload = json!({ "id": 0, "size": 10 });
    if let Ok(resp) = client.post(&url)
        .headers(minegraph_headers())
        .json(&payload)
        .send()
        .await {
        if let Ok(data) = resp.json::<Value>().await {
            return data["data"]["list"].as_array().cloned().unwrap_or_default();
        }
    }
    println!("无法获取资源文件列表。");
    Vec::new()
}

async fn minegraph_get_download_link(resource_id: i64, milestone_id: i64, file_id: i64) -> Option<String> {
    let url = format!("{}/resource/{}/milestones/{}/files/{}", MINEGRAPH_BASE_URL, resource_id, milestone_id, file_id);
    let client = Client::new();
    if let Ok(resp) = client.post(&url)
        .headers(minegraph_headers())
        .json(&json!({}))
        .send()
        .await {
        if let Ok(data) = resp.json::<Value>().await {
            return data["data"].as_str().map(ToString::to_string);
        }
    }
    None
}

fn minegraph_headers() -> HeaderMap {
    let mut h = HeaderMap::new();
    h.insert("app", HeaderValue::from_static("string"));
    h.insert("client", HeaderValue::from_static("string"));
    h.insert("session", HeaderValue::from_static("string"));
    h.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
    h.insert(USER_AGENT, HeaderValue::from_static("Mozilla/5.0 (Windows NT 10.0; Win64; x64)"));
    h
}

fn get_input_minegraph() -> String {
    let mut buf = String::new();
    io::stdin().read_line(&mut buf).unwrap();
    buf
}

fn get_choice_minegraph(max: usize) -> usize {
    if max == 0 { return 0; }
    print!("\n请输入选项 (1-{}，输入 0 退出): ", max);
    io::stdout().flush().unwrap();
    get_input_minegraph().trim().parse::<usize>().unwrap_or(0)
}



async fn unified_main_flow(args: Args) -> Result<(), Box<dyn Error>> {
    let client = Client::new();
    let query = args.query.as_deref().ok_or("请提供 --query")?;
    let mod_type = args.mod_type.as_deref().ok_or("请提供 --mod-type (resourcepacks 或 shaders)")?;
    let src_lower = args.source.to_lowercase();
    let mut projects = Vec::new();

    if src_lower == "modrinth" || src_lower == "both" {
        let md = search_modrinth_projects(&client, query, mod_type, args.version.as_deref(), args.loader.as_deref()).await?;
        projects.extend(md);
    }
    if src_lower == "curse" || src_lower == "both" {
        let cf = search_curseforge_projects(&client, query, mod_type, args.version.as_deref()).await?;
        projects.extend(cf);
    }
    if projects.is_empty() {
        println!("没有找到任何项目...");
        return Ok(());
    }
    let chosen_project = pick_project(&projects)?;
    let versions = fetch_versions(&client, &chosen_project, args.version.as_deref()).await?;
    if versions.is_empty() {
        println!("该项目暂无任何版本。");
        return Ok(());
    }
    let chosen_version = pick_version(&versions)?;
    let files = fetch_files(&client, &chosen_project, &chosen_version).await?;
    if files.is_empty() {
        println!("该版本没有可下载文件。");
        return Ok(());
    }
    let chosen_file = pick_file(&files)?;
    download_and_save(&client, &chosen_project, &chosen_version, &chosen_file, args.save_path.as_deref()).await?;
    Ok(())
}

async fn download_and_save(
    client: &Client,
    project: &UnifiedProject,
    version: &UnifiedVersion,
    file: &UnifiedFile,
    save_dir: Option<&Path>,
) -> Result<(), Box<dyn Error>> {
    if file.download_url.is_empty() {
        println!("无下载链接, 无法下载。");
        return Ok(());
    }
    let filename = derive_filename(project, version, file);
    let out_path = if let Some(dir) = save_dir {
        dir.join(&filename)
    } else {
        PathBuf::from(&filename)
    };

    println!("开始下载: {} ...", file.download_url);
    println!("保存到 {:?}", out_path);

    let head_resp = client.head(&file.download_url).send().await?;
    if !head_resp.status().is_success() {
        eprintln!("HEAD 请求失败: HTTP {}", head_resp.status());
        return single_thread_download(client, &file.download_url, &filename, save_dir).await;
    }
    let headers = head_resp.headers();
    let content_len = headers
        .get("content-length")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(0);
    if content_len == 0 {
        println!("Content-Length 不可用, 回退单线程下载...");
        return single_thread_download(client, &file.download_url, &filename, save_dir).await;
    }
    println!("文件大小: {} 字节", content_len);
    let accept_ranges = headers
        .get("accept-ranges")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");
    if !accept_ranges.eq_ignore_ascii_case("bytes") {
        println!("服务器不支持 Range, 回退单线程下载...");
        return single_thread_download(client, &file.download_url, &filename, save_dir).await;
    }
    let num_chunks = 4;
    let chunk_size = (content_len + num_chunks - 1) / num_chunks;
    {
        let f = File::create(&out_path)?;
        f.set_len(content_len)?;
    }
    let client_arc = Arc::new(client.clone());
    let (tx, mut rx) = mpsc::unbounded_channel();
    for i in 0..num_chunks {
        let start = i * chunk_size;
        if start >= content_len { break; }
        let end = ((i + 1) * chunk_size).min(content_len) - 1;
        let tx_cloned = tx.clone();
        let path_clone = out_path.clone();
        let url_clone = file.download_url.clone();
        let client_clone = client_arc.clone();
        tokio::spawn(async move {
            let range_header = format!("bytes={}-{}", start, end);
            let resp = client_clone.get(&url_clone)
                .header("Range", &range_header)
                .send()
                .await;
            match resp {
                Ok(r) if r.status() == StatusCode::PARTIAL_CONTENT => {
                    match r.bytes().await {
                        Ok(chunk_data) => {
                            if let Err(e) = write_chunk(&path_clone, start, &chunk_data) {
                                let _ = tx_cloned.send(Err(format!("写文件失败: {}", e)));
                            } else {
                                let _ = tx_cloned.send(Ok(()));
                            }
                        },
                        Err(e) => { let _ = tx_cloned.send(Err(format!("分段读取失败: {}", e))); }
                    }
                },
                Ok(r) => { let _ = tx_cloned.send(Err(format!("分段请求状态: {}", r.status()))); },
                Err(e) => { let _ = tx_cloned.send(Err(format!("分段请求错误: {}", e))); }
            }
        });
    }
    drop(tx);
    let mut success_count = 0;
    while let Some(msg) = rx.recv().await {
        match msg {
            Ok(_) => success_count += 1,
            Err(e) => {
                eprintln!("分段下载出错: {}", e);
                return single_thread_download(client, &file.download_url, &filename, save_dir).await;
            }
        }
    }
    if success_count == num_chunks {
        println!("分段下载完成 => {:?}", out_path);
    } else {
        println!("分段下载未全部成功, 回退单线程下载...");
        return single_thread_download(client, &file.download_url, &filename, save_dir).await;
    }
    Ok(())
}

async fn single_thread_download(
    client: &Client,
    url: &str,
    file_name: &str,
    save_dir: Option<&Path>,
) -> Result<(), Box<dyn Error>> {
    let out_path = if let Some(dir) = save_dir {
        dir.join(file_name)
    } else {
        PathBuf::from(file_name)
    };
    println!("单线程下载 => {} 到 {:?}", url, out_path);
    let resp = client.get(url).send().await?;
    if !resp.status().is_success() {
        eprintln!("下载链接出错: HTTP {}", resp.status());
        return Ok(());
    }
    let bytes = resp.bytes().await?;
    std::fs::write(&out_path, &bytes)?;
    println!("单线程下载完成 => {:?}", out_path);
    Ok(())
}


fn write_chunk(path: &Path, start: u64, data: &[u8]) -> std::io::Result<()> {
    let mut f = std::fs::OpenOptions::new().write(true).open(path)?;
    f.seek(SeekFrom::Start(start))?;
    f.write_all(data)?;
    Ok(())
}



async fn search_modrinth_projects(
    client: &Client,
    query: &str,
    mod_type: &str,
    version_filter: Option<&str>,
    loader_filter: Option<&str>,
) -> Result<Vec<UnifiedProject>, Box<dyn Error>> {
    let base = "https://api.modrinth.com/v2/search";
    let mut url = Url::parse(base)?;
    let mut facets_array = vec![];
    let project_type = match mod_type.to_lowercase().as_str() {
        "shaders" => "shader",
        "resourcepacks" => "resourcepack",
        _ => "",
    };
    if !project_type.is_empty() {
        facets_array.push(format!("project_type:{}", project_type));
    }
    if let Some(v) = version_filter {
        facets_array.push(format!("versions:{}", v));
    }
    if let Some(l) = loader_filter {
        facets_array.push(format!("loaders:{}", l.to_lowercase()));
    }
    {
        let mut qp = url.query_pairs_mut();
        qp.append_pair("query", query);
        qp.append_pair("limit", "50");
        if !facets_array.is_empty() {
            let facets = json!([facets_array]);
            qp.append_pair("facets", &facets.to_string());
        }
    }
    let resp = client.get(url).send().await?;
    if !resp.status().is_success() {
        let txt = resp.text().await?;
        println!("Modrinth 搜索出错：{}", txt);
        return Ok(vec![]);
    }
    let data = resp.json::<ModrinthSearchResponse>().await?;
    let mut res = Vec::new();
    for hit in data.hits {
        res.push(UnifiedProject {
            platform: Platform::Modrinth,
            project_id: hit.project_id,
            name: hit.title,
            summary: hit.description.unwrap_or_default(),
        });
    }
    Ok(res)
}

async fn search_curseforge_projects(
    client: &Client,
    query: &str,
    mod_type: &str,
    version_filter: Option<&str>,
) -> Result<Vec<UnifiedProject>, Box<dyn Error>> {
    let base = "https://api.curseforge.com/v1/mods/search";
    let mut url = Url::parse(base)?;
    {
        let mut qp = url.query_pairs_mut();
        qp.append_pair("gameId", "432");
        match mod_type.to_lowercase().as_str() {
            "shaders" => { qp.append_pair("classId", "6552"); },
            "resourcepacks" => { qp.append_pair("classId", "12"); },
            _ => {},
        }
        qp.append_pair("searchFilter", query);
        if let Some(v) = version_filter {
            qp.append_pair("gameVersion", v);
        }
        qp.append_pair("pageSize", "50");
    }
    let data = curseforge_request::<CurseForgeSearchResponse, _>(client, move |api_key| {
        client.get(url.clone()).header("x-api-key", api_key)
    }).await?;
    let mut res = Vec::new();
    for cmod in data.data {
        res.push(UnifiedProject {
            platform: Platform::CurseForge,
            project_id: cmod.id.to_string(),
            name: cmod.name,
            summary: cmod.summary.unwrap_or_default(),
        });
    }
    Ok(res)
}

async fn fetch_versions_curseforge(
    client: &Client,
    project: &UnifiedProject,
    version_filter: Option<&str>,
) -> Result<Vec<UnifiedVersion>, Box<dyn Error>> {
    let mod_id: u64 = project.project_id.parse().unwrap_or(0);
    if mod_id == 0 {
        return Ok(vec![]);
    }
    let url = format!("https://api.curseforge.com/v1/mods/{}/files", mod_id);
    let data = curseforge_request::<CurseForgeFilesResponse, _>(client, move |api_key| {
        client.get(url.clone()).header("x-api-key", api_key)
    }).await?;
    let mut res = Vec::new();
    for f in data.data {
        if let Some(filter) = version_filter {
            if let Some(versions) = &f.gameVersions {
                if !versions.iter().any(|v| v == filter) {
                    continue;
                }
            } else {
                continue;
            }
        }
        res.push(UnifiedVersion {
            version_id: f.id.to_string(),
            name: f.displayName,
            date_published: None,
        });
    }
    Ok(res)
}


async fn fetch_versions_modrinth(
    client: &Client,
    project: &UnifiedProject,
) -> Result<Vec<UnifiedVersion>, Box<dyn Error>> {
    let url = format!("https://api.modrinth.com/v2/project/{}/version", project.project_id);
    let resp = client.get(&url).send().await?;
    if !resp.status().is_success() {
        let txt = resp.text().await?;
        println!("Modrinth 获取版本列表出错：{}", txt);
        return Ok(vec![]);
    }
    let data = resp.json::<Vec<ModrinthVersion>>().await?;
    let mut res = Vec::new();
    for ver in data {
        let vname = ver.name.unwrap_or_else(|| ver.id.clone());
        res.push(UnifiedVersion {
            version_id: ver.id,
            name: vname,
            date_published: Some(ver.date_published),
        });
    }
    Ok(res)
}


async fn fetch_versions(
    client: &Client,
    project: &UnifiedProject,
    version_filter: Option<&str>,
) -> Result<Vec<UnifiedVersion>, Box<dyn Error>> {
    match project.platform {
        Platform::Modrinth => fetch_versions_modrinth(client, project).await,
        Platform::CurseForge => fetch_versions_curseforge(client, project, version_filter).await,
    }
}

#[derive(Debug, Deserialize)]
struct SingleVersionResp {
    files: Vec<ModrinthFileInner>,
}

async fn fetch_files(
    client: &Client,
    project: &UnifiedProject,
    version: &UnifiedVersion,
) -> Result<Vec<UnifiedFile>, Box<dyn Error>> {
    match project.platform {
        Platform::Modrinth => fetch_files_modrinth(client, version).await,
        Platform::CurseForge => fetch_files_curseforge(client, project, version).await,
    }
}


async fn fetch_files_modrinth(
    client: &Client,
    version: &UnifiedVersion,
) -> Result<Vec<UnifiedFile>, Box<dyn Error>> {
    let url = format!("https://api.modrinth.com/v2/version/{}", version.version_id);
    let resp = client.get(&url).send().await?;
    if !resp.status().is_success() {
        let txt = resp.text().await?;
        println!("Modrinth 获取文件列表出错: {}", txt);
        return Ok(vec![]);
    }
    let data = resp.json::<SingleVersionResp>().await?;
    let mut res = Vec::new();
    for f in data.files {
        res.push(UnifiedFile {
            file_id: f.filename.clone(),
            display_name: f.filename.clone(),
            download_url: f.url,
        });
    }
    Ok(res)
}


async fn fetch_files_curseforge(
    client: &Client,
    project: &UnifiedProject,
    version: &UnifiedVersion,
) -> Result<Vec<UnifiedFile>, Box<dyn Error>> {
    let mod_id: u64 = project.project_id.parse().unwrap_or(0);
    let file_id: u64 = version.version_id.parse().unwrap_or(0);
    if mod_id == 0 || file_id == 0 {
        return Ok(vec![]);
    }
    let url = format!("https://api.curseforge.com/v1/mods/{}/files/{}", mod_id, file_id);
    let detail = curseforge_request::<CurseForgeFileDetailResp, _>(client, move |api_key| {
        client.get(url.clone()).header("x-api-key", api_key)
    }).await?;
    let finfo = detail.data;
    let dl = finfo.downloadUrl.unwrap_or_default();
    let final_dl = if dl.is_empty() {
        let display_name = if !finfo.displayName.to_lowercase().ends_with(".zip") {
            format!("{}.zip", finfo.displayName)
        } else {
            finfo.displayName.clone()
        };
        let file_id_str = finfo.id.to_string();
        if file_id_str.len() > 3 {
            let split_index = file_id_str.len() - 3;
            let prefix = &file_id_str[..split_index];
            let suffix = &file_id_str[split_index..];
            format!("https://edge.forgecdn.net/files/{}/{}/{}", prefix, suffix, display_name)
        } else {
            "".to_string()
        }
    } else {
        dl
    };
    let uf = UnifiedFile {
        file_id: finfo.id.to_string(),
        display_name: finfo.displayName,
        download_url: final_dl,
    };
    Ok(vec![uf])
}

fn pick_project(projects: &[UnifiedProject]) -> Result<UnifiedProject, Box<dyn Error>> {
    if projects.len() == 1 {
        return Ok(projects[0].clone());
    }
    let items: Vec<String> = projects.iter()
        .map(|p| format!("{} [{}] - {}", p.name,
                         match p.platform {
                             Platform::Modrinth => "Modrinth",
                             Platform::CurseForge => "CurseForge",
                         },
                         p.summary))
        .collect();
    let sel = Select::with_theme(&ColorfulTheme::default())
        .with_prompt("选择一个项目")
        .items(&items)
        .default(0)
        .interact()?;
    Ok(projects[sel].clone())
}

fn pick_version(versions: &[UnifiedVersion]) -> Result<UnifiedVersion, Box<dyn Error>> {
    if versions.is_empty() {
        return Err("没有版本可供选择".into());
    }
    if versions.len() == 1 {
        return Ok(versions[0].clone());
    }
    let mut sorted_versions = versions.to_vec();
    sorted_versions.sort_by(|a, b| {
        match (&a.date_published, &b.date_published) {
            (Some(date_a), Some(date_b)) => date_b.cmp(date_a),
            (Some(_), None) => std::cmp::Ordering::Less,
            (None, Some(_)) => std::cmp::Ordering::Greater,
            (None, None) => a.name.cmp(&b.name),
        }
    });
    let items: Vec<String> = sorted_versions.iter()
        .map(|v| {
            if let Some(date) = &v.date_published {
                format!("{} (ID: {}) - 发布日期: {}", v.name, v.version_id, date)
            } else {
                format!("{} (ID: {})", v.name, v.version_id)
            }
        })
        .collect();
    let sel = Select::with_theme(&ColorfulTheme::default())
        .with_prompt("选择一个版本")
        .items(&items)
        .default(0)
        .interact()?;
    Ok(sorted_versions[sel].clone())
}

fn pick_file(files: &[UnifiedFile]) -> Result<UnifiedFile, Box<dyn Error>> {
    if files.len() == 1 {
        return Ok(files[0].clone());
    }
    let items: Vec<String> = files.iter()
        .map(|f| format!("{} => {}", f.file_id, f.download_url))
        .collect();
    let sel = Select::with_theme(&ColorfulTheme::default())
        .with_prompt("选择一个文件进行下载")
        .items(&items)
        .default(0)
        .interact()?;
    Ok(files[sel].clone())
}



async fn range_download_fallback(
    url: &str,
    file_name: &str,
    save_dir: Option<&Path>,
) -> Result<(), Box<dyn Error>> {
    let client = Client::new();
    let head_resp = client.head(url).send().await?;
    if !head_resp.status().is_success() {
        eprintln!("HEAD 请求失败: HTTP {}", head_resp.status());
        return single_thread_download(&client, url, file_name, save_dir).await;
    }
    let headers = head_resp.headers();
    let content_len = headers.get("content-length")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(0);
    if content_len == 0 {
        println!("Content-Length 不可用, 回退单线程下载...");
        return single_thread_download(&client, url, file_name, save_dir).await;
    }
    println!("开始下载: {}，文件大小={} 字节", url, content_len);
    let accept_ranges = headers.get("accept-ranges")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");
    if !accept_ranges.eq_ignore_ascii_case("bytes") {
        println!("服务器不支持 Range, 回退单线程下载...");
        return single_thread_download(&client, url, file_name, save_dir).await;
    }
    let num_chunks = 4;
    let chunk_size = (content_len + num_chunks - 1) / num_chunks;
    let out_path = if let Some(dir) = save_dir { dir.join(file_name) } else { PathBuf::from(file_name) };
    {
        let f = File::create(&out_path)?;
        f.set_len(content_len)?;
    }
    let client_arc = Arc::new(client);
    let (tx, mut rx) = mpsc::unbounded_channel();
    for i in 0..num_chunks {
        let start = i * chunk_size;
        if start >= content_len { break; }
        let end = ((i + 1) * chunk_size).min(content_len) - 1;
        let tx_cloned = tx.clone();
        let path_clone = out_path.clone();
        let url_clone = url.to_string();
        let client_clone = client_arc.clone();
        tokio::spawn(async move {
            let range_header = format!("bytes={}-{}", start, end);
            let resp = client_clone.get(&url_clone)
                .header("Range", &range_header)
                .send()
                .await;
            match resp {
                Ok(r) if r.status() == StatusCode::PARTIAL_CONTENT => {
                    match r.bytes().await {
                        Ok(chunk_data) => {
                            if let Err(e) = write_chunk(&path_clone, start, &chunk_data) {
                                let _ = tx_cloned.send(Err(format!("写文件失败: {}", e)));
                            } else {
                                let _ = tx_cloned.send(Ok(()));
                            }
                        },
                        Err(e) => { let _ = tx_cloned.send(Err(format!("分段读取失败: {}", e))); }
                    }
                },
                Ok(r) => { let _ = tx_cloned.send(Err(format!("分段请求状态: {}", r.status()))); },
                Err(e) => { let _ = tx_cloned.send(Err(format!("分段请求错误: {}", e))); }
            }
        });
    }
    drop(tx);
    let mut success_count = 0;
    while let Some(msg) = rx.recv().await {
        match msg {
            Ok(_) => success_count += 1,
            Err(e) => {
                eprintln!("分段下载出错: {}", e);
                return single_thread_download(&*client_arc, url, file_name, save_dir).await;
            }
        }
    }
    if success_count == num_chunks {
        println!("分段下载完成 => {:?}", out_path);
    } else {
        println!("分段下载未全部成功, 回退单线程下载...");
        return single_thread_download(&*client_arc, url, file_name, save_dir).await;
    }
    Ok(())
}

fn derive_filename(project: &UnifiedProject, version: &UnifiedVersion, file: &UnifiedFile) -> String {
    let safe_proj = project.name.replace("/", "_");
    let safe_ver = version.name.replace("/", "_");
    let mut filename = file.display_name.replace("/", "_");

    if !filename.to_lowercase().ends_with(".zip") {
        filename.push_str(".zip");
    }

    format!("{}-{}-{}", safe_proj, safe_ver, filename)
}


#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let args = Args::parse();
    if args.source.to_lowercase() == "minegraph" {
        minegraph_flow(&args).await;
    } else {
        unified_main_flow(args).await?;
    }
    Ok(())
}
